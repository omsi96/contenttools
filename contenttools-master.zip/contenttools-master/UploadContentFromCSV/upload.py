import uploadingContent
    # , SeekingVideos


def configuration():
    print('signing in...')
    uploadingContent.signin()
    print('going to uploading videos..')
    uploadingContent.uploadVideos()
    # start()

# def start():
#     while True:
#         # ask user
#         courseNo = int(input('Enter the course number: '))
#         stageNo = int(input('Enter the stage number: '))
#         videoNo = int(input('Enter the video number: '))
#         print('--------------------------------------------')
#
#         if courseNo not in range(1, 5) or stageNo < 0 or stageNo > 20 or videoNo < 0:
#             print('Wrong entry')
#             continue
#
#         # create video object here
#         SeekingVideos.run('C' + str(courseNo))
#         videos = SeekingVideos.allVideos
#
#
#         # for stage in stages:
#         #     print("* STAGE" + str(stage['topicNumber']) )
#         for video in videos:
#             if video.stage < stageNo:
#                 continue
#             if video.position < videoNo:
#                 continue
#
#             video.printSummary()
#             video.fill(uploadingContent.driver)
#             print('--------\n')
#             i = input('Enter to print on page.... -1 to choose another course')
#             try:
#                 if int(i) == -1:
#                     break
#             except ValueError:
#                 print('continue...')
#                 # uploadingContent.driver.find_element_by_name('_addanother').click()
#
#             # sleep(1)
#             # add another videos
#             # uploadingContent.driver.find_element_by_name('_addanother').click()

# configuration()
# start()