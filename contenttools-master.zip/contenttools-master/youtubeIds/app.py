# -*- coding: utf-8 -*-

# Sample Python code for youtube.playlistItems.list
# See instructions for running these code samples locally:
# https://developers.google.com/explorer-help/guides/code_samples#python

# a = "https://www.youtube.com/playlist?list=PLkIliLHi5M4JKa2b2KxHB5vhMn3rD2a2Q"
import os

import google_auth_oauthlib.flow
import googleapiclient.discovery
import googleapiclient.errors
import google.oauth2.credentials

from flask import Flask, render_template, request, redirect, session, url_for

client_secrets_file = "client_secret_926387611122-cognv5bjj8bn6jb93iuofbcp9cofl28p.apps.googleusercontent.com.json"
api_service_name = "youtube"
api_version = "v3"
scopes = ["https://www.googleapis.com/auth/youtube.readonly"]
maxItemResults = 50
google_auth_redirect_uri = 'http://localhost:5000/googleoauthcallback'

app = Flask(__name__)

app.secret_key = 'FIGOEJ148935-d3kdjfklAJKGLSJ30593'


@app.route('/')
def home():
    services = [{'name': 'Youtube Video Ids from Play List Id', 'url': '/youtubeids/playlist_id=<PLAYLIST_ID>/',
                 'api': '/youtubeids/playlist_id=<PLAYLIST_ID>/?response_type=json'}, ]
    return render_template('home.html', services=services)


@app.route('/youtubeids/<playlist_id>/', methods=['GET'])
def youtube_ids(playlist_id):
    session['current_url'] = request.url
    if request.method == 'GET':

        if 'credentials' not in session:
            return redirect('/authorize')

        items = get_video_ids(playlist_id.split('playlist_id=')[1])
        if request.args.get('response_type') == 'json':
            return {'items': items}
        else:
            return render_template('youtube_ids.html', items=items)
    else:
        return '404'


@app.route('/googleoauthcallback')
def oauth2callback():
    # Specify the state when creating the flow in the callback so that it can
    # verified in the authorization server response.
    state = session['state']

    flow = google_auth_oauthlib.flow.Flow.from_client_secrets_file(
        client_secrets_file, scopes=scopes, state=state)
    flow.redirect_uri = url_for('oauth2callback', _external=True)
    flow.code_verifier = session['code_verifier']

    # Use the authorization server's response to fetch the OAuth 2.0 tokens.
    authorization_response = request.url
    flow.fetch_token(authorization_response=authorization_response)

    # Store credentials in the session.
    # ACTION ITEM: In a production app, you likely want to save these
    #              credentials in a persistent database instead.
    credentials = flow.credentials
    session['credentials'] = credentials_to_dict(credentials)

    return redirect(session['current_url'])


def get_playlist_id_from_url(playlistUrl):
    return playlistUrl.split("list=")[1]


def get_video_ids(playlist_id):
    credentials = google.oauth2.credentials.Credentials(
        **session['credentials'])

    youtube = googleapiclient.discovery.build(
        api_service_name, api_version, credentials=credentials)

    youtube_request = youtube.playlistItems().list(
        part="snippet,contentDetails",
        maxResults=maxItemResults,
        playlistId=playlist_id
    )

    response = youtube_request.execute()

    items = response['items']
    list_items = []

    for c, item in enumerate(items):
        c += 1
        list_items.append({'title': item['snippet']['title'], 'id': item['snippet']['resourceId']['videoId']})
    return list_items


@app.route('/authorize')
def google_oauth():
    # When running locally, disable OAuthlib's HTTPs verification.
    # ACTION ITEM for developers:
    #     When running in production *do not* leave this option enabled.
    os.environ['OAUTHLIB_INSECURE_TRANSPORT'] = '1'

    # Get credentials and create an API client
    flow = google_auth_oauthlib.flow.InstalledAppFlow.from_client_secrets_file(
        client_secrets_file, scopes)
    flow.redirect_uri = google_auth_redirect_uri

    authorization_url, state = flow.authorization_url(
        # Enable offline access so that you can refresh an access token without
        # re-prompting the user for permission. Recommended for web server apps.
        access_type='offline',
        # Enable incremental authorization. Recommended as a best practice.
        include_granted_scopes='true')

    session['code_verifier'] = flow.code_verifier
    session['state'] = state

    return redirect(authorization_url)


def credentials_to_dict(credentials):
    return {'token': credentials.token,
            'refresh_token': credentials.refresh_token,
            'token_uri': credentials.token_uri,
            'client_id': credentials.client_id,
            'client_secret': credentials.client_secret,
            'scopes': credentials.scopes}
