import csv
from Models import *
from upload import configuration
from uploadingContent import signin, driver
# from Project.Sellenuim.upload import configuration
# from Project.Sellenuim.uploadingContent import signin, driver
#
# def readCSV_to_dic(filename):
#     return pd.read_csv(filename, index_col=0, squeeze=True).to_dict()
#
# csv_reader = readCSV_to_dic('Project/Resources/AspNetFullStructure2.csv')
# print(csv_reader)

def readCsv(filename):
    # filename  = 'Project/Resources/AspNetFullStructure2.csv'
    with open(filename) as f:
        reader = csv.DictReader(f)
        data = [r for r in reader]
        return data







def uploadVideosFromCSVData(data):
    configuration()
    for row in data:
        if row['Type'] == 'Video':
            video = Video()
            video.name = row['Step Name']
            video.step_position = row['p']
            video.position = row['p']
            video.description = row['Video Description']
            video.url = row['url']
            video.stage_prd_id = row['stage-prd-id']

            driver.get('https://prd-admin.brmj.co/school/videotutorial/add/')
            print("Filling video: ", video)
            video.fill(driver)

            input("Type anything to continue")
            driver.find_element_by_name('_addanother').click()

data = readCsv(filename = 'ASP_3.csv')
print(data[1])
uploadVideosFromCSVData(data)




