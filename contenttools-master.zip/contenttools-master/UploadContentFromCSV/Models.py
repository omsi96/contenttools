from selenium import webdriver
from selenium.webdriver.support.ui import Select

from selenium.webdriver.common.keys import Keys
import time
import pyperclip


class Video():
    def printSummary(self):
        print('************* video ' + str(self.position) + ' ***************' + 'stage ' + str(self.stage))
        print('NAME:')
        print(self.name)
        print('DESCRIPTION')
        print(self.description)
        print('URL')
        print(self.getUrl())
        pyperclip.copy(self.description)
        print('\n\n \t ** Description is copied to your clipbaord')

        return

# This function call fill from this link: http://backend.brmj.co/school/videotutorial/add/#general
    def fill(self, driver):
        statusFieldId = 'id_status'
        nameFieldId = 'id_name'
        positionFieldId = 'id_position'
        durationFieldId = 'id_duration'
        userFreindlyUrlFieldId = 'id_slug'
        videoFieldId = 'id_video'
        videoYoutubeIdFieldId = 'id_video_youtube_id'
        # descriptionFieldId = 'id_videotutorial_set-' + str(num) +'-status'
        # teacherNoteFieldId = 'id_videotutorial_set-' + str(num) +'-status'


        Select(driver.find_element_by_id(statusFieldId)).select_by_visible_text(self.status)
        Select(driver.find_element_by_id('id_stage')).select_by_value(str(self.stage_prd_id))
        driver.find_element_by_id(nameFieldId).send_keys(self.name)
        driver.find_element_by_id(positionFieldId).send_keys(self.step_position)
        driver.find_element_by_id(durationFieldId).send_keys(self.duration)
        driver.find_element_by_id(userFreindlyUrlFieldId).send_keys(self.url)
        # driver.find_element_by_id(videoFieldId).send_keys('')
        driver.find_element_by_id(videoYoutubeIdFieldId).send_keys(self.videoYoutubeId)

        pyperclip.copy(self.description)

        
# NOT USED NOW: FillInDriver is a function that can fill from stages not from videotutorial/add 
    def fillInDriver(self, driver, num):
        statusFieldId = 'id_videotutorial_set-' + str(num) +'-status'
        nameFieldId = 'id_videotutorial_set-' + str(num) +'-name'
        positionFieldId = 'id_videotutorial_set-' + str(num) +'-position'
        durationFieldId = 'id_videotutorial_set-' + str(num) +'-duration'
        userFreindlyUrlFieldId = 'id_videotutorial_set-' + str(num) +'-slug'
        videoFieldId = 'id_videotutorial_set-' + str(num) +'-video'
        # descriptionFieldId = 'id_videotutorial_set-' + str(num) +'-status'
        # teacherNoteFieldId = 'id_videotutorial_set-' + str(num) +'-status'
        videoYoutubeIdFieldId = 'id_videotutorial_set-' + str(num) +'-video_youtube_id'

        # set published 
        Select(driver.find_element_by_id(statusFieldId)).select_by_visible_text(self.status)
        # set name 
        driver.find_element_by_id(nameFieldId).send_keys(self.name)
        driver.find_element_by_id(positionFieldId).send_keys(self.position)
        driver.find_element_by_id(durationFieldId).send_keys(self.duration)
        driver.find_element_by_id(userFreindlyUrlFieldId).send_keys(self.url)
        driver.find_element_by_id(videoFieldId).send_keys(self.videoYoutubeId)
        driver.find_element_by_id(videoYoutubeIdFieldId).send_keys(self.videoYoutubeId)

    def __init__(self):
        self.status = "published"
        self.name = ""
        self.position = 0 
        self.duration = 0
        self.url = ""
        self.video = ""
        self.description = ""
        self.teacherNote = ""
        self.videoYoutubeId = "-"
        self.topic = 0
        self.stage = 0
        self.step_position = 0
        self.step_type = ""
        self.stage_prd_id = 0

    def getUrl(self):
        return str(self.name.replace(' ', '-'))

    def __str__(self):
        videoClassDescription = ('position: \n' + str(self.position) + '\n')
        videoClassDescription += ('name : \n' + str(self.name) + '\n')
        videoClassDescription += ('description\n: ' + str(self.description) + '\n')
        videoClassDescription += ('duration\n: ' + str(self.duration) + '\n')
        videoClassDescription += ('url: \n' + self.name.replace(' ', '-') + '\n')
        videoClassDescription += ('video: \n' + str(self.video) + '\n')
        videoClassDescription += ('teacherNote: \n' + str(self.teacherNote) + '\n')
        videoClassDescription += ('videoYoutubeId: \n' + str(self.videoYoutubeId) + '\n')
        videoClassDescription += "-----------------------------------\n\n"
        return str(self.__dict__)
        # return videoClassDescription
    def __repr__(self):
        return str(self)




def remove7arakat(string):
    for c in {'َ', 'ً', 'ُ', 'ٌ', 'ّ', 'ِ', 'ٍ', 'ِّ', 'ُّ'}:
            string = string.replace(c, '')
    return string





