# contenttools

## YouTube IDs
To run the app first pip install -r requirements.txt and then flask run.

## CSV Uploader 
Uploads content to the backend using sellenium. This script reads from a csv file that is fromatted as the template available in Google drive. https://docs.google.com/spreadsheets/d/134zGuwrb2WQLGL8hE_qRYnGOZlc4KXco_UIsEJDAX7Q/edit#gid=0

### Steps
1. Open uploadFromCSV.py 
2. Edit the csv file path `data = readCsv(filename = 'ASP_3.csv')`
3. run the script `python uploadFromCSV.py`
