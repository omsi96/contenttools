from selenium import webdriver
import sys, os
from selenium.webdriver.support.ui import Select
from docx import Document
from selenium.webdriver.common.keys import Keys
import time
# import SeekingVideos
print('Opening chrome driver...')
driver = webdriver.Chrome(os.getcwd() + "/chromedriver")


def signin():
    driver.get('https://prd-admin.brmj.co') # login page
    username = "omar@barmej.com"
    password = "omar4456"

    usernameField = driver.find_element_by_name('username')
    passwordField = driver.find_element_by_name('password')

    usernameField.send_keys(username)
    passwordField.send_keys(password)
    passwordField.send_keys(Keys.RETURN)


def uploadVideos():
    driver.get('https://prd-admin.brmj.co/school/videotutorial/add/')
    # driver.get('http://backend.brmj.co/school/stage/1100/change/?_changelist_filters=q%3D%25D9%2584%25D8%25BA%25D8%25A9%2BC#videotutorials')




# signin()
# uploadVideos()



#
# courses = []
# for p in doc.paragraphs:
#     line = p.text
#     if line.startswith('Course'):
#         course = [line.split(':')]
#         courses.append(line)
#     if line.startswith('topic'):
#
# print(courses)
